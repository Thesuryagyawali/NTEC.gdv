const express = require("express");
const path = require("path")

const PORT = 3000;
const app = express();

const http = require("http");
const httpServer = http.createServer(app);

const { Server } = require("socket.io");
const io = new Server(httpServer);

let MODE = 1;

app.use(express.static("public"))

app.get("/admin", (req, res) => {
    res.sendFile(path.join(__dirname, 'views/index.html'));
})

app.get("/mode", (req, res) => {
    // res.send(MODE)
    res.send(`${MODE}`)
})

app.get('/changemode', (req, res) => {
    const {mode} = req.query

    console.log("MODE:", mode)
    MODE = mode

    res.send(mode)
})

app.get("/old", (req, res)=> {
    // if (MODE != "2") {
    //     res.status(404)
    //     res.send("err")
    //     return
    // }
    const { calltype } = req.query

    console.log("old mode",calltype)
    io.emit("message", calltype)
    res.send("OK")
})

io.on("connection", (socket) => {
    console.log("CONNECTED")
    // socket.on("chat message", async (msg) => {
    //   io.emit("chat message", msg);
    //   // pubClient.hset
    //   await pubClient.hSet('lol', 'fiesald', "SAD");
    // });
    // socket.on("click", () => {
    // })
});
  
httpServer.listen(PORT, "192.168.0.105");